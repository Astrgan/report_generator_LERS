﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace report_generator_LERS
{
    /// <summary>
    /// Interaction logic for settings.xaml
    /// </summary>
    public partial class settings : Window
    {
        public settings()
        {
            InitializeComponent();
            text.Text = Properties.Settings.Default.PathTemplate;
            textPathHourRep.Text = Properties.Settings.Default.PathTemplateHour;
            text_TEC1.Text = Properties.Settings.Default.PathTemplateTEC1;
            textPathHourRepTEC2.Text = Properties.Settings.Default.PathTemplateHourTEC1;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.PathTemplate = text.Text;
            Properties.Settings.Default.PathTemplateHour = textPathHourRep.Text;
            Properties.Settings.Default.PathTemplateTEC1 = text_TEC1.Text;
            Properties.Settings.Default.PathTemplateHourTEC1 = textPathHourRepTEC2.Text;

            Properties.Settings.Default.Save();
            this.Close();
        }

        private void Button_Click_day_TEC2(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog
            {
                FileName = "TemplateLERS",
                DefaultExt = ".xls",
                Filter = "Excel Worksheets|*.xls|*.xlsx|*.xlsm"
            };
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                // Open document
                text.Text = dlg.FileName;
            }
        }

        private void Button_Click_hour_TEC2(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog
            {
                FileName = "TemplateLERS_HOUR",
                DefaultExt = ".xls",
                Filter = "Excel Worksheets|*.xls|*.xlsx|*.xlsm"
            };
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                // Open document
                textPathHourRep.Text = dlg.FileName;
            }
        }

        private void Button_Click_day_TEC1(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog
            {
                FileName = "TemplateLERS_TEC1",
                DefaultExt = ".xls",
                Filter = "Excel Worksheets|*.xls|*.xlsx|*.xlsm"
            };
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                // Open document
                text_TEC1.Text = dlg.FileName;
            }
        }

        private void Button_Click_hour_TEC1(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog
            {
                FileName = "TemplateLERS_TEC1_HOUR",
                DefaultExt = ".xls",
                Filter = "Excel Worksheets|*.xls|*.xlsx|*.xlsm"
            };
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                // Open document
                textPathHourRepTEC2.Text = dlg.FileName;
            }
        }
    }
}
