﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace report_generator_LERS
{
    class Dates
    {
        public DateTime date_start;
        public DateTime date_end;

        public Dates(DateTime date_start, DateTime date_end)
        {
            this.date_start = date_start;
            this.date_end = date_end;
        }
    }
}
