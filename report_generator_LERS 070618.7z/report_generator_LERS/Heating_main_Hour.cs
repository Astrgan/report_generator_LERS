﻿using Lers.Data;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Application = Microsoft.Office.Interop.Excel.Application;
using Excel = Microsoft.Office.Interop.Excel;



namespace report_generator_LERS
{
    class Heating_main_Hour
    {
        private int ro;
        int flagTEC;
        public double?[] arrayM1 = new double?[24];
        public double?[] arrayM2 = new double?[24];
        public double?[] arrayDM = new double?[24];

        public double?[] arrayQ1 = new double?[24];
        public double?[] arrayQ2 = new double?[24];
        public double?[] arrayDQ = new double?[24];

        public double?[] arrayT1 = new double?[24];
        public double?[] arrayT2 = new double?[24];

        public double?[] arrayP1 = new double?[24];
        public double?[] arrayP2 = new double?[24];

        public double? T1=0;
        public double? T2=0;
        public double? D1=0;
        public double? D2=0;
        public double? dD=0;
        public double? dQ=0;
        public double? Q1=0;
        public double? Q2=0;
        public double? Tamur=0;


        private int num_hm;
        private DateTime startDate;
        private string login;
        private string password;
        MeasurePointConsumptionRecordCollection consumptionData;
        MeasurePointConsumptionRecordCollection consumptionDataDay;
   

        public Heating_main_Hour(int num_hm, DateTime startDate, String login, String password, int flagTEC)
        {
            this.flagTEC = flagTEC;
            this.num_hm = num_hm;
            this.startDate = startDate;
            this.login = login;
            this.password = password; 
        }


        public int Connect()
        {
            try
            {
                var server = new Lers.LersServer(num_hm.ToString());                // Создаём объект для подключения к серверу
                var authInfo = new Lers.Networking.BasicAuthenticationInfo(login, Lers.Networking.SecureStringHelper.ConvertToSecureString(password)); // Информация для аутентификации (логин и пароль учётной записи)           
            
                server.Connect("10.100.6.142", 10000, authInfo);
                var measurePoint = server.MeasurePoints.GetByNumber(num_hm);        // Ищем точку учёта. В этом примере мы получем её по номеру.

                DateTime endDate = startDate.AddHours(23);
                consumptionData = measurePoint.Data.GetConsumption(startDate, endDate, Lers.Data.DeviceDataType.Hour);
                consumptionDataDay = measurePoint.Data.GetConsumption(startDate, endDate, Lers.Data.DeviceDataType.Day); //получаем данные (суточные)
            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter("log.txt", true))
                {
                    writer.WriteLine("Message :" + ex.Message + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
                return 1;
            }

            return 0;
        }

        public int Process()
        {
            int i = 0;
            foreach (var consumptionRecord in consumptionData)
            {
                arrayM1[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.M_in);
                arrayM2[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.M_out);
                arrayDM[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.M_delta);

                arrayQ1[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.Q_in);
                arrayQ2[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.Q_out);
                arrayDQ[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.Q_delta);

                arrayT1[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.T_in);
                arrayT2[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.T_out);

                arrayP1[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.P_in);
                arrayP2[i] = consumptionRecord.GetValue(Lers.Data.DataParameter.P_out);

                i++;
                
            }

            double? multiply_sum = 0;
            double? sum_M = 0;

            for(i = 0; i<24; i++)
            {
                multiply_sum += arrayT1[i] * arrayM1[i];
                sum_M += arrayM1[i];
            }
            if (sum_M != 0) T1 = multiply_sum / sum_M; else T1 = 0;

            multiply_sum = 0;
            sum_M = 0;
            for (i = 0; i < 24; i++)
            {
                multiply_sum += arrayT2[i] * arrayM2[i];
                sum_M += arrayM2[i];
            }
            if (sum_M != 0) T2 = multiply_sum / sum_M; else T2 = 0;

            foreach (double? value in arrayM1) D1 += value;
            
            foreach (double? value in arrayM2) D2 += value;
            
            foreach (double? value in arrayDM) dD += value;

            foreach (double? value in arrayQ1) Q1 += value;
            
            foreach (double? value in arrayQ2) Q2 += value;
           
            foreach (double? value in arrayDQ) dQ += value;

            foreach (var consumptionRecord in consumptionDataDay)Tamur = consumptionRecord.GetValue(Lers.Data.DataParameter.T_cw);
           
            /* Округляем  */
            if (flagTEC == 1) ro = 2;
            else if (flagTEC == 2) ro = 1;

            T1 = Math.Round(T1.GetValueOrDefault(), ro);
            T2 = Math.Round(T2.GetValueOrDefault(), ro);
            D1 = Math.Round(D1.GetValueOrDefault(), 0);
            D2 = Math.Round(D2.GetValueOrDefault(), 0);
            dD = Math.Round(dD.GetValueOrDefault(), 0);
            Q1 = Math.Round(Q1.GetValueOrDefault(), 0);
            Q2 = Math.Round(Q2.GetValueOrDefault(), 0);
            dQ = Math.Round(dQ.GetValueOrDefault(), 0);
            Tamur = Math.Round(Tamur.GetValueOrDefault(), ro);
           


            return 0;
        }


    }
}
