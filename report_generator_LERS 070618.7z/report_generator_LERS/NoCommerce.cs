﻿using System;


namespace report_generator_LERS
{
    class NoCommerce
    {


        private int num_hm1 = 5;
        private int num_hm2 = 6;
        private string login;
        private DateTime startDate;
        private string password;

        public double? obesolVoda;
        public double? massaParaNaMazutoHoz;
        public double? parNaMazutoHoz;
        public double? gvk;


        public NoCommerce(DateTime startDate, String login, String password)
        {
            
            this.startDate = startDate;
            this.login = login;
            this.password = password;
        }

        public int Start()
        {

            var server = new Lers.LersServer(num_hm2.ToString());                // Создаём объект для подключения к серверу
            var authInfo = new Lers.Networking.BasicAuthenticationInfo(login, Lers.Networking.SecureStringHelper.ConvertToSecureString(password)); // Информация для аутентификации (логин и пароль учётной записи)           
            try
            {
                server.Connect("10.100.6.142", 10000, authInfo);
            }
            catch
            {
                return 1;
            }
            var measurePoint = server.MeasurePoints.GetByNumber(num_hm2);        // Ищем точку учёта. В этом примере мы получем её по номеру.


            DateTime endDate = startDate.AddHours(23);


            //получаем остальные данные сразу суточными
            var consumptionData = measurePoint.Data.GetConsumption(startDate, endDate, Lers.Data.DeviceDataType.Day); //получаем данные (суточные)
            foreach (var consumptionRecord in consumptionData)
            {
                
                massaParaNaMazutoHoz = consumptionRecord.GetValue(Lers.Data.DataParameter.M_in);
                parNaMazutoHoz = consumptionRecord.GetValue(Lers.Data.DataParameter.Q_in);
                gvk = consumptionRecord.GetValue(Lers.Data.DataParameter.M_out);
            }



            /*****************************************************/

            server = new Lers.LersServer(num_hm1.ToString());                // Создаём объект для подключения к серверу
            authInfo = new Lers.Networking.BasicAuthenticationInfo(login, Lers.Networking.SecureStringHelper.ConvertToSecureString(password)); // Информация для аутентификации (логин и пароль учётной записи)           
            try
            {
                server.Connect("10.100.6.142", 10000, authInfo);
            }
            catch
            {
                return 1;
            }
            measurePoint = server.MeasurePoints.GetByNumber(num_hm1);        // Ищем точку учёта. В этом примере мы получем её по номеру.


            endDate = startDate.AddHours(23);

            //получаем остальные данные сразу суточными
            consumptionData = measurePoint.Data.GetConsumption(startDate, endDate, Lers.Data.DeviceDataType.Day); //получаем данные (суточные)
            foreach (var consumptionRecord in consumptionData)
            {
                obesolVoda = consumptionRecord.GetValue(Lers.Data.DataParameter.M_in);
            }




            obesolVoda = Math.Round(obesolVoda.GetValueOrDefault(), 0);
            massaParaNaMazutoHoz = Math.Round(massaParaNaMazutoHoz.GetValueOrDefault(), 0);
            parNaMazutoHoz = Math.Round(parNaMazutoHoz.GetValueOrDefault(), 0);
            gvk = Math.Round(gvk.GetValueOrDefault(), 0);
            return 0;
        }
    }
}
