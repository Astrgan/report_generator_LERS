﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Windows;
using Excel = Microsoft.Office.Interop.Excel;
using Application = Microsoft.Office.Interop.Excel.Application;
using System.Threading;

namespace report_generator_LERS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        bool flag_day = Properties.Settings.Default.dayType;
        Worksheet wbSheet;
        int b = 20;
        int multiplier = 0;
        int int_old_day = 1;
        String login, password;
        private Workbook wb;
        private Application app;
        private Workbook wbTemplate;
        private Heating_main_Hour heating_Main;
        private int errorFlag;

        public MainWindow(String login, String password)
        {
            this.login = login;
            this.password = password;
            InitializeComponent();
            DateTime dateTime = DateTime.Now;
            dateTime = dateTime.AddDays(-1);
            DateForHour.SelectedDate = dateTime;

            old_day.Content = "0" + int_old_day;
            inc_day.Content = "\u02C4";
            dec_day.Content = "\u02C5";

            if (flag_day)
            {
                Reinvert_flag_day();
                rb2.IsChecked = true;
            }
            else
            {
                Invert_flag_day();
                rb1.IsChecked = true;
            }
        }


        int Create_Excel_book(String pathExcelTemplate)
        {
            app = new Application();
            if (app == null) { MessageBox.Show("Excel is not properly installed!!"); return 1; }
            wb = app.Workbooks.Add(Type.Missing);
            try
            {
                wbTemplate = app.Workbooks.Open(pathExcelTemplate);
            }
            catch
            {
                MessageBox.Show("Укажите путь к шаблону EXCEL");
                settings settings = new settings();
                settings.Show();
                return 1;
            }
            wbTemplate.Sheets[1].Copy(After: wb.Worksheets[1]);
            wbTemplate.Close();
            wbSheet = (Excel.Worksheet)wb.Worksheets.get_Item(2);
            return 0;
        }

        void Process(DateTime date)
        {

            int[] num_heating_mains = new int[] { 21, 10, 2, 8, 3, 1, 213, 4 };
            int j = 3;
            for (int i = 0; i < num_heating_mains.Length; i++)
            {
                LERS_GO(num_heating_mains[i], date);

                wbSheet.Cells[9 + b * multiplier, j] = heating_Main.T1;
                wbSheet.Cells[10 + b * multiplier, j] = heating_Main.T2;
                wbSheet.Cells[11 + b * multiplier, j] = heating_Main.D1;
                wbSheet.Cells[12 + b * multiplier, j] = heating_Main.D2;
                wbSheet.Cells[13 + b * multiplier, j] = heating_Main.dD;
                wbSheet.Cells[14 + b * multiplier, j] = heating_Main.dQ;
                wbSheet.Cells[15 + b * multiplier, j] = heating_Main.Tamur;
                j += 1;
            }

            wbSheet.Cells[7 + b * multiplier, 1] = "с " + date.ToString("dd.MM.yyyy") + " " + date.ToShortTimeString() + "  по  " + date.ToString("dd.MM.yyyy") + " " + "23:00";

            NoCommerce noCommerce = new NoCommerce(date, login, password);
            noCommerce.Start();
            wbSheet.Cells[21 + b * multiplier, 9] = noCommerce.obesolVoda;
            wbSheet.Cells[22 + b * multiplier, 9] = noCommerce.massaParaNaMazutoHoz;
            wbSheet.Cells[23 + b * multiplier, 9] = noCommerce.parNaMazutoHoz;
            wbSheet.Cells[24 + b * multiplier, 9] = noCommerce.gvk;
        }

        private void Button_Click_Day_Rep(object sender, RoutedEventArgs e)
        {
            ButtonDayRep.IsEnabled = false;
            GenDayRep();
            ButtonDayRep.IsEnabled = true;
        }


        private void GenDayRep()
        {
            int x1 = 7;
            int y1 = 1;
            int x2 = 24;
            int y2 = 15;
            b = 20;
            multiplier = 0;

            DateTime date_start, date_end;

            if (true)
            {
                bool flag = true;

                if (flag_day)
                {
                    DateTime dateTime = DateTime.Now.Date.Add(new TimeSpan(0, 0, 0));
                    date_start = dateTime.AddDays(int_old_day * (-1));
                    date_end = dateTime.AddDays(-1);

                }
                else
                {
                    if (data_start_cal.SelectedDate != null && data_end_cal.SelectedDate != null)
                    {
                        date_start = data_start_cal.SelectedDate.Value;
                        date_end = data_end_cal.SelectedDate.Value;
                    }
                    else
                    {
                        MessageBox.Show("задайте начальную и конечную дату");
                        return;
                    }
                }

                int errorFlag = Create_Excel_book(@Properties.Settings.Default.PathTemplate);
                if (errorFlag == 1) return; // ошибка, заканчиваем выполнение функции
                wbSheet.Cells[4, 3] = " за период с  " + date_start.ToString("dd.MM.yyyy") + " " + date_start.ToShortTimeString() + "  по  " + date_end.ToString("dd.MM.yyyy") + " " + "23:00";

                Process(date_start);
                multiplier = 1;

                if (!System.DateTime.Equals(date_start, date_end))
                {
                    date_start = date_start.AddDays(1);
                    while (flag)
                    {

                        if (System.DateTime.Equals(date_start, date_end))
                        {
                            flag = false;
                        }

                        Excel.Range rng_from = wbSheet.Range[wbSheet.Cells[x1, y1], wbSheet.Cells[x2, y2]];
                        Excel.Range rng_to = wbSheet.Range[wbSheet.Cells[x1 + b * multiplier, y1], wbSheet.Cells[x2 + b * multiplier, y2]];
                        rng_from.Copy(rng_to);
                        Process(date_start);

                        multiplier++;
                        date_start = date_start.AddDays(1);

                    }
                }

            }

            app.Visible = true;
        }

        private void Inc_day(object sender, RoutedEventArgs e)
        {
            if (int_old_day < 30)
            {
                int_old_day++;
                old_day.Content = "0" + int_old_day;
            }
        }

        private void Dec_day(object sender, RoutedEventArgs e)
        {
            if (int_old_day > 1)
            {
                int_old_day--;
                old_day.Content = "0" + int_old_day;
            }
        }

        private void Invert_flag_day(object sender, RoutedEventArgs e)
        {
            Invert_flag_day();
            Properties.Settings.Default.dayType = false;
            Properties.Settings.Default.Save();
        }



        private void Reinvert_flag_day(object sender, RoutedEventArgs e)
        {
            Reinvert_flag_day();
            Properties.Settings.Default.dayType = true;
            Properties.Settings.Default.Save();
        }



        private void Invert_flag_day()
        {
            flag_day = false;
            data_start_cal.IsEnabled = true;
            data_end_cal.IsEnabled = true;

            inc_day.IsEnabled = false;
            dec_day.IsEnabled = false;
            old_day.IsEnabled = false;
            day_back_old.IsEnabled = false;
        }

        private void Reinvert_flag_day()
        {
            flag_day = true;
            data_start_cal.IsEnabled = false;
            data_end_cal.IsEnabled = false;

            inc_day.IsEnabled = true;
            dec_day.IsEnabled = true;
            old_day.IsEnabled = true;
            day_back_old.IsEnabled = true;
        }

        private void Button_Click_Setting(object sender, RoutedEventArgs e)
        {
            settings settings = new settings();
            settings.Show();
        }

        private void Button_Click_Haur_Rep(object sender, RoutedEventArgs e)
        {
            ButtonHourRep.IsEnabled = false;
            GenHourRep(DateForHour.SelectedDate.Value);
            ButtonHourRep.IsEnabled = true;
        }

        private void GenHourRep(DateTime date)
        {
           

            int errorFlag = Create_Excel_book(@Properties.Settings.Default.PathTemplateHour);
            if (errorFlag == 1) return; // ошибка, заканчиваем выполнение функции



            int[] num_heating_mains = new int[] { 2, 8, 3, 21, 10, 1 };

            int y = 113;
            int x1 = 4;
            int x2 = 4;
            for (int i = 0; i < num_heating_mains.Length; i++)
            {
                LERS_GO(num_heating_mains[i], date);



                for (int j = 0; j < 24; j++)
                {
                    wbSheet.Cells[y + j,   x1] = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1+1] = Math.Round(heating_Main.arrayM2[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1+2] = Math.Round(heating_Main.arrayDM[j].GetValueOrDefault(), 1);


                    wbSheet.Cells[y + j + 29, x1] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j + 29, x1 + 1] = Math.Round(heating_Main.arrayQ2[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j + 29, x1 + 2] = Math.Round(heating_Main.arrayDQ[j].GetValueOrDefault(), 1);

                    wbSheet.Cells[y + j + 58, x2]     = Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j + 58, x2 + 1] = Math.Round(heating_Main.arrayT2[j].GetValueOrDefault(), 1);

                }

                x1 += 3;
                x2 += 2;
                
            }
            
            y = 200;
            x1 = 4;
            LERS_GO(4, date);

            
            for (int j = 0; j < 24; j++)
            {
                wbSheet.Cells[y + j, x1] = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1+2] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 4] = Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 6] = Math.Round(heating_Main.arrayP1[j].GetValueOrDefault(), 1);
            }


            LERS_GO(213, date);
            x1 = 5;

            for (int j = 0; j < 24; j++)
            {
                wbSheet.Cells[y + j, x1] = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 2] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 4] = Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 6] = Math.Round(heating_Main.arrayP1[j].GetValueOrDefault(), 1);
            }
            wbSheet.Cells[109, 1] = date.ToString("dd.MM.yyyy");
            app.Visible = true;
        }

        private void LERS_GO(int num, DateTime date)
        {
            heating_Main = new Heating_main_Hour(num, date, login, password);
            errorFlag = heating_Main.Connect();
            if (errorFlag == 1)
            {
                wb.Close(0);
                app.Quit();
                MessageBox.Show("Не удалось войти в систему. Имя входа или пароль указаны неверно");
                AuthWindow authWindow = new AuthWindow();
                authWindow.Show();
                this.Close();
                return;
            }
            heating_Main.Process();
        }
    }
}

