﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace report_generator_LERS
{
    /// <summary>
    /// Interaction logic for settings.xaml
    /// </summary>
    public partial class settings : Window
    {
        public settings()
        {
            InitializeComponent();
            text.Text = Properties.Settings.Default.PathTemplate;

            textPathHourRep.Text = Properties.Settings.Default.PathTemplateHour;
            
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.PathTemplate = text.Text;
            Properties.Settings.Default.PathTemplateHour = textPathHourRep.Text;
            Properties.Settings.Default.Save();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "TemplateLERS";
            dlg.DefaultExt = ".xls";
            dlg.Filter = "Excel Worksheets|*.xls|*.xlsx|*.xlsm";
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                // Open document
                text.Text = dlg.FileName;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "TemplateLERS_HOUR";
            dlg.DefaultExt = ".xls";
            dlg.Filter = "Excel Worksheets|*.xls|*.xlsx|*.xlsm";
            Nullable<bool> result = dlg.ShowDialog();

            if (result == true)
            {
                // Open document
                textPathHourRep.Text = dlg.FileName;
            }
        }


    }
}
