﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Windows;
using System.Threading;

namespace report_generator_LERS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        bool flag_day = Properties.Settings.Default.dayType;
        Worksheet wbSheet;
        int b = 20;
        int multiplier = 0;
        int int_old_day = 1;
        String login, password;
        private Heating_main_Hour heating_Main;
        private int errorFlag;
        Logics lodics;

        public MainWindow(String login, String password)
        {
            this.login = login;
            this.password = password;
            InitializeComponent();
            DateTime dateTime = DateTime.Now;
            dateTime = dateTime.AddDays(-1);
            DateForHour.SelectedDate = dateTime;

            old_day.Content = "0" + int_old_day;
            inc_day.Content = "\u02C4";
            dec_day.Content = "\u02C5";

            if (flag_day)
            {
                Reinvert_flag_day();
                rb2.IsChecked = true;
            }
            else
            {
                Invert_flag_day();
                rb1.IsChecked = true;
            }

            lodics = new Logics(login, password);
        }


 

        private void Button_Click_Day_Rep(object sender, RoutedEventArgs e)
        {
            ButtonDayRep.IsEnabled = false;
            lodics.GenDayRep(int_old_day);
            ButtonDayRep.IsEnabled = true;
        }




        private void Inc_day(object sender, RoutedEventArgs e)
        {
            if (int_old_day < 30)
            {
                int_old_day++;
                old_day.Content = "0" + int_old_day;
            }
        }

        private void Dec_day(object sender, RoutedEventArgs e)
        {
            if (int_old_day > 1)
            {
                int_old_day--;
                old_day.Content = "0" + int_old_day;
            }
        }

        private void Invert_flag_day(object sender, RoutedEventArgs e)
        {
            Invert_flag_day();
            Properties.Settings.Default.dayType = false;
            Properties.Settings.Default.Save();
        }



        private void Reinvert_flag_day(object sender, RoutedEventArgs e)
        {
            Reinvert_flag_day();
            Properties.Settings.Default.dayType = true;
            Properties.Settings.Default.Save();
        }



        private void Invert_flag_day()
        {
            flag_day = false;
            data_start_cal.IsEnabled = true;
            data_end_cal.IsEnabled = true;

            inc_day.IsEnabled = false;
            dec_day.IsEnabled = false;
            old_day.IsEnabled = false;
            day_back_old.IsEnabled = false;
        }

        private void Reinvert_flag_day()
        {
            flag_day = true;
            data_start_cal.IsEnabled = false;
            data_end_cal.IsEnabled = false;

            inc_day.IsEnabled = true;
            dec_day.IsEnabled = true;
            old_day.IsEnabled = true;
            day_back_old.IsEnabled = true;
        }

        private void Button_Click_Setting(object sender, RoutedEventArgs e)
        {
            settings settings = new settings();
            settings.Show();
        }

        private void Button_Click_Haur_Rep(object sender, RoutedEventArgs e)
        {
            ButtonHourRep.IsEnabled = false;
            lodics.GenHourRep(DateForHour.SelectedDate.Value);
            ButtonHourRep.IsEnabled = true;
        }


    }
}

