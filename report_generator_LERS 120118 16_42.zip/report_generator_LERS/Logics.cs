﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using Application = Microsoft.Office.Interop.Excel.Application;
using Microsoft.Office.Interop.Excel;

namespace report_generator_LERS
{




    class Logics
    {


        bool flag_day = Properties.Settings.Default.dayType;
        Worksheet wbSheet;
        int b = 20;
        int multiplier = 0;
        String login, password;
        private Workbook wb;
        private Application app;
        private Workbook wbTemplate;
        private Heating_main_Hour heating_Main;
        private int errorFlag;
        DateTime date_start, date_end;

        public Logics(string login, string password)
        {
            this.login = login;
            this.password = password;
        }

        public int GenDayRep(int int_old_day)
        {

            DateTime dateTime = DateTime.Now.Date.Add(new TimeSpan(0, 0, 0));
            date_start = dateTime.AddDays(int_old_day * (-1));
            date_end = dateTime.AddDays(-1);
            startGenRepDay();
            return 0;
        }

        public int GenDayRep(DateTime date_start, DateTime date_end)
        {

                if (date_start != null && date_start != null)
                {
                    this.date_start = date_start;
                    this.date_end = date_start;
                }
                else
                {            
                    return 1;//MessageBox.Show("задайте начальную и конечную дату");
                }
            startGenRepDay();
            return 0;
        }


        private void startGenRepDay()
        {

            int x1 = 7;
            int y1 = 1;
            int x2 = 24;
            int y2 = 15;
            b = 20;
            multiplier = 0;


            int errorFlag = Create_Excel_book(@Properties.Settings.Default.PathTemplate);
            if (errorFlag == 1) return; // ошибка, заканчиваем выполнение функции
            wbSheet.Cells[4, 3] = " за период с  " + date_start.ToString("dd.MM.yyyy") + " " + date_start.ToShortTimeString() + "  по  " + date_end.ToString("dd.MM.yyyy") + " " + "23:00";

            Process(date_start);
            multiplier = 1;

            if (!System.DateTime.Equals(date_start, date_end))
            {
                date_start = date_start.AddDays(1);
                bool flag = true;
                while (flag)
                {

                    if (System.DateTime.Equals(date_start, date_end))
                    {
                        flag = false;
                    }

                    Excel.Range rng_from = wbSheet.Range[wbSheet.Cells[x1, y1], wbSheet.Cells[x2, y2]];
                    Excel.Range rng_to = wbSheet.Range[wbSheet.Cells[x1 + b * multiplier, y1], wbSheet.Cells[x2 + b * multiplier, y2]];
                    rng_from.Copy(rng_to);
                    Process(date_start);

                    multiplier++;
                    date_start = date_start.AddDays(1);

                }
            }



            app.Visible = true;
        }

        int Create_Excel_book(String pathExcelTemplate)
        {
            app = new Application();
            if (app == null)   return 1; //MessageBox.Show("Excel is not properly installed!!");
            wb = app.Workbooks.Add(Type.Missing);
            try
            {
                wbTemplate = app.Workbooks.Open(pathExcelTemplate);
            }
            catch
            {
                //MessageBox.Show("Укажите путь к шаблону EXCEL");
                settings settings = new settings();
                settings.Show();
                return 1;
            }
            wbTemplate.Sheets[1].Copy(After: wb.Worksheets[1]);
            wbTemplate.Close();
            wbSheet = (Excel.Worksheet)wb.Worksheets.get_Item(2);
            return 0;
        }

        public void Process(DateTime date)
        {

            int[] num_heating_mains = new int[] { 21, 10, 2, 8, 3, 1, 213, 4 };
            int j = 3;
            for (int i = 0; i < num_heating_mains.Length; i++)
            {
                LERS_GO(num_heating_mains[i], date);

                wbSheet.Cells[9 + b * multiplier, j] = heating_Main.T1;
                wbSheet.Cells[10 + b * multiplier, j] = heating_Main.T2;
                wbSheet.Cells[11 + b * multiplier, j] = heating_Main.D1;
                wbSheet.Cells[12 + b * multiplier, j] = heating_Main.D2;
                wbSheet.Cells[13 + b * multiplier, j] = heating_Main.dD;
                wbSheet.Cells[14 + b * multiplier, j] = heating_Main.dQ;
                wbSheet.Cells[15 + b * multiplier, j] = heating_Main.Tamur;
                j += 1;
            }

            wbSheet.Cells[7 + b * multiplier, 1] = "с " + date.ToString("dd.MM.yyyy") + " " + date.ToShortTimeString() + "  по  " + date.ToString("dd.MM.yyyy") + " " + "23:00";

            NoCommerce noCommerce = new NoCommerce(date, login, password);
            noCommerce.Start();
            wbSheet.Cells[21 + b * multiplier, 9] = noCommerce.obesolVoda;
            wbSheet.Cells[22 + b * multiplier, 9] = noCommerce.massaParaNaMazutoHoz;
            wbSheet.Cells[23 + b * multiplier, 9] = noCommerce.parNaMazutoHoz;
            wbSheet.Cells[24 + b * multiplier, 9] = noCommerce.gvk;
        }

        public void GenHourRep(DateTime date)
        {


            int errorFlag = Create_Excel_book(@Properties.Settings.Default.PathTemplateHour);
            if (errorFlag == 1) return; // ошибка, заканчиваем выполнение функции



            int[] num_heating_mains = new int[] { 2, 8, 3, 21, 10, 1 };

            int y = 113;
            int x1 = 4;
            int x2 = 4;
            for (int i = 0; i < num_heating_mains.Length; i++)
            {
                LERS_GO(num_heating_mains[i], date);



                for (int j = 0; j < 24; j++)
                {
                    wbSheet.Cells[y + j, x1] = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1 + 1] = Math.Round(heating_Main.arrayM2[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1 + 2] = Math.Round(heating_Main.arrayDM[j].GetValueOrDefault(), 1);


                    wbSheet.Cells[y + j + 29, x1] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j + 29, x1 + 1] = Math.Round(heating_Main.arrayQ2[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j + 29, x1 + 2] = Math.Round(heating_Main.arrayDQ[j].GetValueOrDefault(), 1);

                    wbSheet.Cells[y + j + 58, x2] = Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j + 58, x2 + 1] = Math.Round(heating_Main.arrayT2[j].GetValueOrDefault(), 1);

                }

                x1 += 3;
                x2 += 2;

            }

            y = 200;
            x1 = 4;
            LERS_GO(4, date);


            for (int j = 0; j < 24; j++)
            {
                wbSheet.Cells[y + j, x1] = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 2] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 4] = Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 6] = Math.Round(heating_Main.arrayP1[j].GetValueOrDefault(), 1);
            }


            LERS_GO(213, date);
            x1 = 5;

            for (int j = 0; j < 24; j++)
            {
                wbSheet.Cells[y + j, x1] = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 2] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 4] = Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1);
                wbSheet.Cells[y + j, x1 + 6] = Math.Round(heating_Main.arrayP1[j].GetValueOrDefault(), 1);
            }
            wbSheet.Cells[109, 1] = date.ToString("dd.MM.yyyy");
            app.Visible = true;
        }

        int LERS_GO(int num, DateTime date)
        {
            heating_Main = new Heating_main_Hour(num, date, login, password);
            errorFlag = heating_Main.Connect();
            if (errorFlag == 1)
            {
                wb.Close(0);
                app.Quit();
                AuthWindow authWindow = new AuthWindow();
                authWindow.Show();
                authWindow.ShowErrorMessage();
                return 1;
            }
            heating_Main.Process();
            return 0;
        }
    }


    
}
