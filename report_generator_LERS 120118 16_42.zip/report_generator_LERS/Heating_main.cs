﻿using System;


namespace report_generator_LERS

{
    class Heating_main
    {
        public double? T1;
        public double? T2;
        public double? D1;
        public double? D2;
        public double? dD;
        public double? dQ;
        public double? Tamur;
        private int num_hm;
        private string login;
        private DateTime startDate;
        private string password;

        public Heating_main(int num_hm, DateTime startDate, String login, String password)
        {
            this.num_hm = num_hm;
            this.startDate = startDate;
            this.login = login;
            this.password = password;
        }

        public int Start ()
        {

            var server = new Lers.LersServer(num_hm.ToString());                // Создаём объект для подключения к серверу
            var authInfo = new Lers.Networking.BasicAuthenticationInfo(login, Lers.Networking.SecureStringHelper.ConvertToSecureString(password)); // Информация для аутентификации (логин и пароль учётной записи)           
            try
            {
                server.Connect("10.100.6.142", 10000, authInfo);
            }
            catch
            {
                return 1;
            }
            var measurePoint = server.MeasurePoints.GetByNumber(num_hm);        // Ищем точку учёта. В этом примере мы получем её по номеру.


            DateTime endDate = startDate.AddHours(23);
            var consumptionData = measurePoint.Data.GetConsumption(startDate, endDate, Lers.Data.DeviceDataType.Hour); //получаем данные (часовы для расчета средневзвешанных)

            double? multiply_sum1 = 0;
            double? sum_M_in1 = 0;
            double? multiply_sum2 = 0;
            double? sum_M_in2 = 0;


            // получение температуры и расчет средневзыешенной 
            foreach (var consumptionRecord in consumptionData)
            {
                double? value_T_in1 = consumptionRecord.GetValue(Lers.Data.DataParameter.T_in);
                double? value_M_in1 = consumptionRecord.GetValue(Lers.Data.DataParameter.M_in);
                string stringValue = value_T_in1.HasValue ? value_T_in1.Value.ToString() : "<нет данных>";

                multiply_sum1 += value_T_in1 * value_M_in1;
                sum_M_in1 += value_M_in1;

                double? value_T_in2 = consumptionRecord.GetValue(Lers.Data.DataParameter.T_out);
                double? value_M_in2 = consumptionRecord.GetValue(Lers.Data.DataParameter.M_out);
                string stringValue2 = value_T_in2.HasValue ? value_T_in2.Value.ToString() : "<нет данных>";

                multiply_sum2 += value_T_in2 * value_M_in2;
                sum_M_in2 += value_M_in2;
            }

            if (sum_M_in1 != 0) T1 = multiply_sum1 / sum_M_in1; else T1 = 0;
            if (sum_M_in2 != 0) T2 = multiply_sum2 / sum_M_in2; else T2 = 0;

            //получаем остальные данные сразу суточными
            consumptionData = measurePoint.Data.GetConsumption(startDate, endDate, Lers.Data.DeviceDataType.Day); //получаем данные (суточные)
            foreach (var consumptionRecord in consumptionData)
            {
                D1 = consumptionRecord.GetValue(Lers.Data.DataParameter.M_in);
                D2 = consumptionRecord.GetValue(Lers.Data.DataParameter.M_out);
                dD = consumptionRecord.GetValue(Lers.Data.DataParameter.M_delta);
                dQ = consumptionRecord.GetValue(Lers.Data.DataParameter.Q_delta);
                Tamur = consumptionRecord.GetValue(Lers.Data.DataParameter.T_cw);
            }



            /* Округляем 

            T1 = Math.Round(T1.GetValueOrDefault(), 1);
            T2 = Math.Round(T2.GetValueOrDefault(), 1);
            D1 = Math.Round(D1.GetValueOrDefault(), 0);
            D2 = Math.Round(D2.GetValueOrDefault(), 0);
            dD = Math.Round(dD.GetValueOrDefault(), 0);
            dQ = Math.Round(dQ.GetValueOrDefault(), 0);
            Tamur = Math.Round(Tamur.GetValueOrDefault());
           */ /*
            T1 = Math.Round(T1.GetValueOrDefault(), 1);
            T2 = Math.Round(T2.GetValueOrDefault(), 1);
            D1 = Math.Truncate(D1.GetValueOrDefault());
            D2 = Math.Truncate(D2.GetValueOrDefault());
            dD = Math.Truncate(dD.GetValueOrDefault());
            dQ = Math.Truncate(dQ.GetValueOrDefault());
            Tamur = Math.Round(Tamur.GetValueOrDefault(), 1);
            */
            return 0;
        }
    }
}
