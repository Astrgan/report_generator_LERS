﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Windows;
using System.Threading;

namespace report_generator_LERS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        bool flag_day = Properties.Settings.Default.dayType;
        int int_old_day = 1;
        String login, password;
        Logics logics;


        public MainWindow(String login, String password)
        {
            this.login = login;
            this.password = password;
            InitializeComponent();

            DateTime dateTime = DateTime.Now;
            dateTime = dateTime.AddDays(-1);
            DateForHour.SelectedDate = dateTime;

            old_day.Content = "0" + int_old_day;
            inc_day.Content = "\u02C4";
            dec_day.Content = "\u02C5";

            if (flag_day)
            {
                Reinvert_flag_day();
                rb2.IsChecked = true;
            }
            else
            {
                Invert_flag_day();
                rb1.IsChecked = true;
            }

            logics = new Logics(login, password);
            logics.Error += this.Error;
            logics.FIN += this.ReblockButton;
        }


 

        private void Button_Click_Day_Rep(object sender, RoutedEventArgs e)
        {
            ReblockButton();

            if (flag_day)
            {
                Thread myThread = new Thread(new ParameterizedThreadStart(logics.GenDayRepCaunt));
                myThread.Start(int_old_day);
            }
            else
            {
                if (date_start_cal.SelectedDate != null && date_end_cal.SelectedDate != null)
                {
                    Dates dates = new Dates(date_start_cal.SelectedDate.Value, date_end_cal.SelectedDate.Value);
                    Thread myThread = new Thread(new ParameterizedThreadStart(logics.GenDayRepTwoDate));
                    myThread.Start(dates);
                    
                }
                else
                {
                    MessageBox.Show("задайте начальную и конечную дату");
                    return;
                }

            }
            
        }

        private void Button_Click_Haur_Rep(object sender, RoutedEventArgs e)
        {
            ButtonHourRep.IsEnabled = false;

            Thread myThread = new Thread(new ParameterizedThreadStart(logics.GenHourRepTEC2));
            myThread.Start(DateForHour.SelectedDate.Value);

        }

        void ReblockButton()
        {
            Dispatcher.Invoke(() => 
            {
                ButtonDayRep.IsEnabled = !ButtonDayRep.IsEnabled;
                ButtonHourRep.IsEnabled =!ButtonHourRep.IsEnabled;
            });
            
        }
        void Error(int errorFlag)
        {
            if (errorFlag == 1)
            {
                MessageBox.Show("Не удалось войти в систему. Логин или пароль указаны неверно");
                Dispatcher.Invoke(() => 
                {
                    AuthWindow authWindow = new AuthWindow();
                    authWindow.Show();
                    this.Close();
                });
               
            }
            if (errorFlag == 10)
            {

                Dispatcher.Invoke(() =>
                {
                    MessageBox.Show("Укажите путь к шаблону EXCEL");
                    settings settings = new settings();
                    settings.Show();
                    //ButtonDayRep.IsEnabled = true;
                    //ButtonHourRep.IsEnabled = true;
                });

            }
            if (errorFlag == 11) MessageBox.Show("Excel не установлен!!");
            if (errorFlag == 20) MessageBox.Show("Начальная дата больше конечной");
        }


        private void Inc_day(object sender, RoutedEventArgs e)
        {
            if (int_old_day < 30)
            {
                int_old_day++;
                old_day.Content = "0" + int_old_day;
            }
        }

        private void Dec_day(object sender, RoutedEventArgs e)
        {
            if (int_old_day > 1)
            {
                int_old_day--;
                old_day.Content = "0" + int_old_day;
            }
        }

        private void Invert_flag_day(object sender, RoutedEventArgs e)
        {
            Invert_flag_day();
            Properties.Settings.Default.dayType = false;
            Properties.Settings.Default.Save();
        }



        private void Reinvert_flag_day(object sender, RoutedEventArgs e)
        {
            Reinvert_flag_day();
            Properties.Settings.Default.dayType = true;
            Properties.Settings.Default.Save();
        }



        private void Invert_flag_day()
        {
            flag_day = false;
            date_start_cal.IsEnabled = true;
            date_end_cal.IsEnabled = true;

            inc_day.IsEnabled = false;
            dec_day.IsEnabled = false;
            old_day.IsEnabled = false;
            day_back_old.IsEnabled = false;
        }

        private void Reinvert_flag_day()
        {
            flag_day = true;
            date_start_cal.IsEnabled = false;
            date_end_cal.IsEnabled = false;

            inc_day.IsEnabled = true;
            dec_day.IsEnabled = true;
            old_day.IsEnabled = true;
            day_back_old.IsEnabled = true;
        }

        private void Button_Click_Setting(object sender, RoutedEventArgs e)
        {
            settings settings = new settings();
            settings.Show();
        }
    }
}

