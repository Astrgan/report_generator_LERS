﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace report_generator_LERS
{
    /// <summary>
    /// Interaction logic for AuthWindow.xaml
    /// </summary>
    public partial class AuthWindow : Window
    {
        int checkFlag = 0;
        public AuthWindow()
        {
            InitializeComponent();

            if (Properties.Settings.Default.checkSave)
            {
                login_text_block.Text = Properties.Settings.Default.login;
                pass_text_block.Password = Properties.Settings.Default.password;
                checkBox.IsChecked = true;
            }

        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            if (login_text_block.Text == String.Empty || pass_text_block.Password == String.Empty)
            {
                MessageBox.Show("Введите данные авторизации");
                return;
            }

            if (login_text_block.Text.Length > 15 || pass_text_block.Password.Length > 15)
            {
                MessageBox.Show("Логин или пароль слишком длинный");
                return;

            }

            
            if (checkFlag == 1)
            {
                Properties.Settings.Default.login = login_text_block.Text;
                Properties.Settings.Default.password = pass_text_block.Password;
                Properties.Settings.Default.checkSave = true;
                Properties.Settings.Default.Save();
                
            }
            if (checkFlag == 2)
            {
                if(!(Properties.Settings.Default.login == "" && Properties.Settings.Default.password == ""))
                {
                    Properties.Settings.Default.password = "";
                    Properties.Settings.Default.login = "";
                }

                if (Properties.Settings.Default.checkSave)
                {
                    Properties.Settings.Default.checkSave = false;
                }
                Properties.Settings.Default.Save();
            }

            MainWindow mainWindow = new MainWindow(login_text_block.Text, pass_text_block.Password);
            mainWindow.Show();
            this.Close();
        }

        private void Checked(object sender, RoutedEventArgs e)
        {
            checkFlag = 1;
        }

        private void Unchecked(object sender, RoutedEventArgs e)
        {
            checkFlag = 2;
        }



    }
}
