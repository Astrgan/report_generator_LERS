﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using Application = Microsoft.Office.Interop.Excel.Application;
using Microsoft.Office.Interop.Excel;
using System.IO;

namespace report_generator_LERS
{

    class Logics
    {
        public int flagTEC;
        public delegate void MethodLoading(double progress);
        public event MethodLoading Load;
        public delegate void MethodFIN();
        public event MethodFIN FIN;
        public delegate void MethodError(int error);
        public event MethodError Error; 
        bool flag_day = Properties.Settings.Default.dayType;
        Worksheet wbSheet;
        double atomLoad = 0;
        int b = 20;
        int multiplier = 0;
        String login, password;
        private Workbook wb;
        private Application app;
        private Workbook wbTemplate;
        private Heating_main_Hour heating_Main;
        private int errorFlag;
        DateTime date_start, date_end;
        public int[] num_heating_mains;

        public Logics(string login, string password, int flagTEC)
        {
            this.login = login;
            this.password = password;
            this.flagTEC = flagTEC;
            SetFlagTEC(flagTEC);
        }

        public void GenDayRepCaunt(object o_int_old_day)
        {
            int int_old_day = (int)o_int_old_day;
            DateTime dateTime = DateTime.Now.Date.Add(new TimeSpan(0, 0, 0));
            date_start = dateTime.AddDays(int_old_day * (-1));
            date_end = dateTime.AddDays(-1);
            errorFlag = StartGenRepDayTEC2();
            if (errorFlag != 0) Error(errorFlag);
            
        }

        public void GenDayRepTwoDate(object o_dates)
        {
            Dates dates = (Dates)o_dates;

            if (DateTime.Compare(dates.date_start, dates.date_end) <= 0)
                {
                    this.date_start = dates.date_start;
                    this.date_end = dates.date_end;
                }
                else
                {
                    Error(20);  //Начальная дата больше конечной;
                }
            errorFlag = StartGenRepDayTEC2();
            if (errorFlag != 0) Error(errorFlag);

        }

        private int StartGenRepDayTEC2()
        {
            int x1 = 7;
            int y1 = 1;
            int x2 = 24;
            int y2 = 16;
            b = 20;
            multiplier = 0;
            atomLoad =  (100.0 / num_heating_mains.Length) / ((date_end.Day - date_start.Day) + 1); 

            if(flagTEC == 2) errorFlag = Create_Excel_book(@Properties.Settings.Default.PathTemplateTEC2);
            if (flagTEC == 1) errorFlag = Create_Excel_book(@Properties.Settings.Default.PathTemplateTEC1);
            if (errorFlag != 0)
            {
                FIN();
                return errorFlag; // ошибка c Excel, заканчиваем выполнение функции                
            }
            wbSheet.Cells[4, 3] = " за период с  " + date_start.ToString("dd.MM.yyyy") + " " + date_start.ToShortTimeString() + "  по  " + date_end.ToString("dd.MM.yyyy") + " " + "23:00";

            errorFlag = Process(date_start);
            if (errorFlag == 1) return errorFlag;

            multiplier = 1;

            if (!System.DateTime.Equals(date_start, date_end))
            {
                date_start = date_start.AddDays(1);
             
                bool flag = true;
                while (flag)
                {

                    if (System.DateTime.Equals(date_start, date_end))
                    {
                        flag = false;
                    }
                    PrintLog();
                    Excel.Range rng_from = wbSheet.Range[wbSheet.Cells[x1, y1], wbSheet.Cells[x2, y2]];
                    Excel.Range rng_to = wbSheet.Range[wbSheet.Cells[x1 + b * multiplier, y1], wbSheet.Cells[x2 + b * multiplier, y2]];
                    rng_from.Copy(rng_to);
                    Process(date_start);

                    multiplier++;
                    date_start = date_start.AddDays(1);
                    PrintLog();
                }
            }
            FIN();
            app.Visible = true;
            return 0;
        }

        private void PrintLog()
        {
            Console.WriteLine("\n\n*****************************************");
            Console.WriteLine("Date start: " + date_start.ToShortDateString() + "\n" + "Time start: " + date_start.ToShortTimeString());
            Console.WriteLine("Date end: " + date_end.ToShortDateString() + "\n" + "Time start: " + date_end.ToShortTimeString());
            Console.WriteLine("*****************************************\n\n");
        }

        int Create_Excel_book(String pathExcelTemplate)
        {
            try
            {
                app = new Application();
                wb = app.Workbooks.Add(Type.Missing);
                wbTemplate = app.Workbooks.Open(pathExcelTemplate);
            }
            catch(Exception ex)
            {
                using (StreamWriter writer = new StreamWriter("log.txt", true))
                {
                    writer.WriteLine(login + " Message :" + ex.Message + "<br/>" + Environment.NewLine + "StackTrace :" + ex.StackTrace +
                       "" + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                }
                if (app == null) return 11; //Excel не установлен!!;
                app.Quit();
                return 10;  //Укажите путь к шаблону EXCEL
            }
            wbTemplate.Sheets[1].Copy(After: wb.Worksheets[1]);
            wbTemplate.Close();
            wbSheet = (Excel.Worksheet)wb.Worksheets.get_Item(2);
            //app.Visible = true;
            return 0;
        }

        public void SetFlagTEC(int flag)
        {
            flagTEC = flag;
            if (flagTEC == 2)
                num_heating_mains = new int[] { 21, 10, 2, 8, 3, 1, 213, 4 };
            else if (flagTEC == 1)
                num_heating_mains = new int[] { 63, 64, 65, 68, 70 };
        }

        public int Process(DateTime date)
        {
            int j = 3;
            for (int i = 0; i < num_heating_mains.Length; i++)
            {
                errorFlag = LERS_GO(num_heating_mains[i], date);
                if (errorFlag != 0) return 1;
                int y = 9;
                wbSheet.Cells[y + b * multiplier, j] = heating_Main.T1;     y++;
                wbSheet.Cells[y + b * multiplier, j] = heating_Main.T2;     y++;
                wbSheet.Cells[y + b * multiplier, j] = heating_Main.D1;     y++;
                wbSheet.Cells[y + b * multiplier, j] = heating_Main.D2;     y++;
                wbSheet.Cells[y + b * multiplier, j] = heating_Main.dD;     y++;
                if (flagTEC == 1)
                {
                    wbSheet.Cells[y + b * multiplier, j] = heating_Main.Q1; y++;
                    wbSheet.Cells[y + b * multiplier, j] = heating_Main.Q2; y++;
                }           
                wbSheet.Cells[y + b * multiplier, j] = heating_Main.dQ;     y++;
                wbSheet.Cells[y + b * multiplier, j] = heating_Main.Tamur;  y++;
                j += 1;
                if(num_heating_mains[i] == 213) j += 1; //делаем пропуск для колонки "ГВС от города"

                Load(atomLoad);
            }

            wbSheet.Cells[7 + b * multiplier, 1] = "с " + date.ToString("dd.MM.yyyy") + " " + date.ToShortTimeString() + "  по  " + date.ToString("dd.MM.yyyy") + " " + "23:00";

            if (flagTEC == 2)
            {
                NoCommerce noCommerce = new NoCommerce(date, login, password);
                noCommerce.Start();
                wbSheet.Cells[21 + b * multiplier, 9] = noCommerce.obesolVoda;
                wbSheet.Cells[22 + b * multiplier, 9] = noCommerce.massaParaNaMazutoHoz;
                wbSheet.Cells[23 + b * multiplier, 9] = noCommerce.parNaMazutoHoz;
                wbSheet.Cells[24 + b * multiplier, 9] = noCommerce.gvk;
            }

            
            return 0;
        }

        public void GenHourRep(object o_date)
        {
            DateTime date = (DateTime)o_date;
            if (flagTEC == 2) num_heating_mains = new int[] { 2, 8, 3, 21, 10, 1 };
            atomLoad = (100.0 / num_heating_mains.Length) / 24;
            if (flagTEC == 2) errorFlag = Create_Excel_book(@Properties.Settings.Default.PathTemplateHourTEC2);
            if (flagTEC == 1) errorFlag = Create_Excel_book(@Properties.Settings.Default.PathTemplateHourTEC1);
            if (errorFlag != 0)
            {
                FIN();
                Error(errorFlag); // ошибка с Excel, заканчиваем выполнение функции
                return;
            }


            int y = 113;
            int x1 = 4;
            int x2 = 4;
            for (int i = 0; i < num_heating_mains.Length; i++)
            {
                errorFlag = LERS_GO(num_heating_mains[i], date);
                if (errorFlag == 1)
                {
                    Error(1);
                    return;
                }

                for (int j = 0; j < 24; j++)
                {
                    wbSheet.Cells[y + j, x1] = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1 + 1] = Math.Round(heating_Main.arrayM2[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1 + 2] = Math.Round(heating_Main.arrayDM[j].GetValueOrDefault(), 1);

                    wbSheet.Cells[y + j + 29, x1] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j + 29, x1 + 1] = Math.Round(heating_Main.arrayQ2[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j + 29, x1 + 2] = Math.Round(heating_Main.arrayDQ[j].GetValueOrDefault(), 1);

                    wbSheet.Cells[y + j + 58, x2] = heating_Main.arrayM1[j] != 0 ? Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1) : 0;
                    wbSheet.Cells[y + j + 58, x2 + 1] = heating_Main.arrayM2[j] != 0 ? Math.Round(heating_Main.arrayT2[j].GetValueOrDefault(), 1) : 0;
                    if (flagTEC == 1)
                    {
                        wbSheet.Cells[y + j + 87, x2] = Math.Round(heating_Main.arrayP1[j].GetValueOrDefault(), 1);
                        wbSheet.Cells[y + j + 87, x2 + 1] = Math.Round(heating_Main.arrayP2[j].GetValueOrDefault(), 1);
                    }
                    Load(atomLoad);

                }

                x1 += 3;
                x2 += 2;

            }
            if (flagTEC == 2)
            {
                y = 200;
                x1 = 4;
                errorFlag = LERS_GO(4, date);
                if (errorFlag == 1)
                {
                    Error(1);
                    return;
                }

                for (int j = 0; j < 24; j++)
                {
                    wbSheet.Cells[y + j, x1]     = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1 + 2] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1 + 4] = heating_Main.arrayM1[j] != 0 ? Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1) : 0;
                    wbSheet.Cells[y + j, x1 + 6] = heating_Main.arrayM1[j] != 0 ? Math.Round(heating_Main.arrayP1[j].GetValueOrDefault(), 1) : 0;
                }


                errorFlag = LERS_GO(213, date);
                if (errorFlag == 1)
                {
                    Error(1);
                    return;
                }
                x1 = 5;

                for (int j = 0; j < 24; j++)
                {
                    wbSheet.Cells[y + j, x1] = Math.Round(heating_Main.arrayM1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1 + 2] = Math.Round(heating_Main.arrayQ1[j].GetValueOrDefault(), 1);
                    wbSheet.Cells[y + j, x1 + 4] = heating_Main.arrayM1[j] != 0 ? Math.Round(heating_Main.arrayT1[j].GetValueOrDefault(), 1) : 0;
                    wbSheet.Cells[y + j, x1 + 6] = heating_Main.arrayM1[j] != 0 ? Math.Round(heating_Main.arrayP1[j].GetValueOrDefault(), 1) : 0;
                }
            }
            wbSheet.Cells[109, 1] = date.ToString("dd.MM.yyyy");
            app.Visible = true;
            FIN();

        }//GenHourRep


        
        int LERS_GO(int num, DateTime date)
        {
            heating_Main = new Heating_main_Hour(num, date, login, password, flagTEC);
            errorFlag = heating_Main.Connect();
            if (errorFlag == 1)
            {
                wb.Close(0);
                app.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(app);

                return 1;
            }
            heating_Main.Process();
            return 0;
        }
    }


    
}
