﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace report_generator_LERS

{
    class Heating_main
    {
        public double? T1;
        public double? T2;
        public double? D1;
        public double? D2;
        public double? dD;
        public double? dQ;
        public double? Tamur;



        public Heating_main(int num_hm, DateTime startDate, String login, String password)
        {

            var server = new Lers.LersServer(num_hm.ToString());                // Создаём объект для подключения к серверу
            var authInfo = new Lers.Networking.BasicAuthenticationInfo(login, Lers.Networking.SecureStringHelper.ConvertToSecureString(password)); // Информация для аутентификации (логин и пароль учётной записи)           
            server.Connect("10.100.6.142", 10000, authInfo);
            var measurePoint = server.MeasurePoints.GetByNumber(num_hm);        // Ищем точку учёта. В этом примере мы получем её по номеру.


            var endDate = startDate.AddHours(23);
            var consumptionData = measurePoint.Data.GetConsumption(startDate, endDate, Lers.Data.DeviceDataType.Hour); //получаем данные (часовы для расчета средневзвешанных)

            double? multiply_sum1 = 0;
            double? sum_M_in1 = 0;
            double? multiply_sum2 = 0;
            double? sum_M_in2 = 0;


            // получение температуры и расчет средневзыешенной 
            foreach (var consumptionRecord in consumptionData)
            {
                double? value_T_in1 = consumptionRecord.GetValue(Lers.Data.DataParameter.T_in);
                double? value_M_in1 = consumptionRecord.GetValue(Lers.Data.DataParameter.M_in);
                string stringValue = value_T_in1.HasValue ? value_T_in1.Value.ToString() : "<нет данных>";

                multiply_sum1 += value_T_in1 * value_M_in1;
                sum_M_in1 += value_M_in1;

                double? value_T_in2 = consumptionRecord.GetValue(Lers.Data.DataParameter.T_out);
                double? value_M_in2 = consumptionRecord.GetValue(Lers.Data.DataParameter.M_out);
                string stringValue2 = value_T_in2.HasValue ? value_T_in2.Value.ToString() : "<нет данных>";

                multiply_sum2 += value_T_in2 * value_M_in2;
                sum_M_in2 += value_M_in2;
            }

            if (sum_M_in1 != 0) T1 = multiply_sum1 / sum_M_in1; else T1 = 0;
            if (sum_M_in2 != 0) T2 = multiply_sum2 / sum_M_in2; else T2 = 0;

            //получаем остальные данные сразу суточными
            consumptionData = measurePoint.Data.GetConsumption(startDate, endDate, Lers.Data.DeviceDataType.Day); //получаем данные (суточные)
            foreach (var consumptionRecord in consumptionData)
            {
                D1 = consumptionRecord.GetValue(Lers.Data.DataParameter.M_in);
                D2 = consumptionRecord.GetValue(Lers.Data.DataParameter.M_out);
                dD = consumptionRecord.GetValue(Lers.Data.DataParameter.M_delta);
                dQ = consumptionRecord.GetValue(Lers.Data.DataParameter.Q_delta);
                Tamur = consumptionRecord.GetValue(Lers.Data.DataParameter.T_cw);
            }
        }
    }
}
